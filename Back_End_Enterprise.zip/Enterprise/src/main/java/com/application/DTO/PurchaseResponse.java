package com.application.DTO;

import lombok.Data;

@Data
public class PurchaseResponse {
	
	private final String orderTrackingNumber;

}
