package com.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootFirst1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
